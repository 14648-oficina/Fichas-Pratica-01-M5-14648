<?php
    $name = $_POST["name"];
    $age = $_POST["age"];
    $pass = $_POST["password"];
    $size = strlen($pass);
    if($age >= 18){
        $agerange = "Adult";
    
    }  elseif ($age <= 12){
        $agerange = "Child";
   
    }else{
        $agerange = "Teenager";
    }
    if($size < 5){
        $pwstrenght1 = "❌ Your Password is Weak ";
        $pwstrenght2 = "(Not Enough Characters, Recommended size is above 8)";
        $warningcolour = "(228, 0, 0)";
    }elseif ($size > 8){
        $pwstrenght1 = "✔️ Your Password is Very Strong";
        $pwstrenght2 = "";
        $warningcolour = "(0, 195, 0)";
    }else{  
        $pwstrenght1 = "🟡 Your Password is Alright ";
        $pwstrenght2 = "(Not Enough Characters, Recommended size is above 8)";
        $warningcolour = "(230, 150, 2)";
    }
    echo "Hello, $name! Welcome!<br/>";
    echo "Age Group: $agerange ($age)<br/>";
    echo "<span style='color:rgb$warningcolour;'>$pwstrenght1</span>$pwstrenght2"
    
?>